import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMiningConfigSchema, insertMiningStatsSchema } from "@shared/schema";
import { DuinoCoinClient } from "./duino-client";
import { z } from "zod";

// Global mining client instance
let miningClient: DuinoCoinClient | null = null;
let miningStats = {
  hashRate: 0,
  temperature: 45,
  powerDraw: 2.5,
  uptime: 0,
  startTime: 0
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Mining configuration routes
  app.get("/api/mining/config", async (req, res) => {
    try {
      const userId = 1; // Default user for demo
      const config = await storage.getMiningConfig(userId);
      res.json(config);
    } catch (error) {
      res.status(500).json({ message: "Failed to get mining configuration" });
    }
  });

  app.post("/api/mining/config", async (req, res) => {
    try {
      const userId = 1; // Default user for demo
      console.log('Received config data:', req.body);
      
      const configData = insertMiningConfigSchema.parse({ ...req.body, userId });
      console.log('Parsed config data:', configData);
      
      const existingConfig = await storage.getMiningConfig(userId);
      let config;
      
      if (existingConfig) {
        console.log('Updating existing config');
        config = await storage.updateMiningConfig(userId, configData);
      } else {
        console.log('Creating new config');
        config = await storage.createMiningConfig(configData);
      }
      
      console.log('Saved config:', config);
      res.json(config);
    } catch (error) {
      console.error('Config save error:', error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid configuration data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to save mining configuration" });
      }
    }
  });

  // Mining stats routes
  app.get("/api/mining/stats", async (req, res) => {
    try {
      const userId = 1; // Default user for demo
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const stats = await storage.getMiningStats(userId, limit);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to get mining statistics" });
    }
  });

  app.get("/api/mining/stats/latest", async (req, res) => {
    try {
      const userId = 1; // Default user for demo
      const stats = await storage.getLatestMiningStats(userId);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to get latest mining statistics" });
    }
  });

  app.post("/api/mining/stats", async (req, res) => {
    try {
      const userId = 1; // Default user for demo
      const statsData = insertMiningStatsSchema.parse({ ...req.body, userId });
      const stats = await storage.createMiningStats(statsData);
      res.json(stats);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid statistics data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to save mining statistics" });
      }
    }
  });

  // Hardware info routes
  app.get("/api/hardware", async (req, res) => {
    try {
      const hardware = await storage.getHardwareInfo();
      res.json(hardware);
    } catch (error) {
      res.status(500).json({ message: "Failed to get hardware information" });
    }
  });

  // Mining control routes
  app.post("/api/mining/start", async (req, res) => {
    try {
      const userId = 1; // Default user for demo
      const config = await storage.getMiningConfig(userId);
      
      if (!config || !config.username) {
        return res.status(400).json({ 
          message: "Please configure your Duino-Coin username first" 
        });
      }

      // Create new mining client
      miningClient = new DuinoCoinClient(config.username, config.rigIdentifier || "3DS");
      
      // Set up stats monitoring
      miningClient.onStats((stats) => {
        miningStats.hashRate = stats.hashRate;
        miningStats.uptime = miningStats.startTime ? Math.floor((Date.now() - miningStats.startTime) / 1000) : 0;
        
        // Simulate temperature and power based on intensity
        miningStats.temperature = 45 + (config.intensity * 3) + (Math.random() * 5);
        miningStats.powerDraw = 1.5 + (config.intensity * 0.8) + (Math.random() * 0.5);
        
        // Store mining stats
        storage.createMiningStats({
          userId,
          hashRate: stats.hashRate,
          sharesAccepted: stats.sharesAccepted,
          sharesRejected: stats.sharesRejected,
          temperature: miningStats.temperature,
          powerDraw: miningStats.powerDraw,
          uptime: miningStats.uptime
        });
      });

      // Connect to Duino-Coin server
      const connected = await miningClient.connect();
      
      if (!connected) {
        return res.status(500).json({ 
          message: "Failed to connect to Duino-Coin server" 
        });
      }

      // Start mining
      const miningStarted = miningClient.startMining();
      
      if (!miningStarted) {
        return res.status(500).json({ 
          message: "Failed to start mining" 
        });
      }

      miningStats.startTime = Date.now();
      const updatedConfig = await storage.updateMiningConfig(userId, { isActive: true });
      
      res.json({ 
        message: "Real Duino-Coin mining started successfully", 
        config: updatedConfig 
      });
    } catch (error) {
      console.error("Mining start error:", error);
      res.status(500).json({ message: "Failed to start mining" });
    }
  });

  app.post("/api/mining/stop", async (req, res) => {
    try {
      const userId = 1; // Default user for demo
      
      if (miningClient) {
        miningClient.stopMining();
        miningClient.disconnect();
        miningClient = null;
      }
      
      miningStats.startTime = 0;
      const config = await storage.updateMiningConfig(userId, { isActive: false });
      
      res.json({ message: "Mining stopped", config });
    } catch (error) {
      res.status(500).json({ message: "Failed to stop mining" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
