import { 
  users, 
  miningConfigs, 
  miningStats, 
  hardwareInfo,
  type User, 
  type InsertUser,
  type MiningConfig,
  type InsertMiningConfig,
  type MiningStats,
  type InsertMiningStats,
  type HardwareInfo,
  type InsertHardwareInfo
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Mining configuration methods
  getMiningConfig(userId: number): Promise<MiningConfig | undefined>;
  createMiningConfig(config: InsertMiningConfig): Promise<MiningConfig>;
  updateMiningConfig(userId: number, config: Partial<MiningConfig>): Promise<MiningConfig | undefined>;
  
  // Mining stats methods
  getMiningStats(userId: number, limit?: number): Promise<MiningStats[]>;
  createMiningStats(stats: InsertMiningStats): Promise<MiningStats>;
  getLatestMiningStats(userId: number): Promise<MiningStats | undefined>;
  
  // Hardware info methods
  getHardwareInfo(): Promise<HardwareInfo | undefined>;
  createHardwareInfo(info: InsertHardwareInfo): Promise<HardwareInfo>;
  updateHardwareInfo(info: Partial<HardwareInfo>): Promise<HardwareInfo | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private miningConfigs: Map<number, MiningConfig>;
  private miningStats: Map<number, MiningStats[]>;
  private hardwareInfo: HardwareInfo | undefined;
  private currentUserId: number;
  private currentConfigId: number;
  private currentStatsId: number;

  constructor() {
    this.users = new Map();
    this.miningConfigs = new Map();
    this.miningStats = new Map();
    this.currentUserId = 1;
    this.currentConfigId = 1;
    this.currentStatsId = 1;
    
    // Initialize default hardware info
    this.hardwareInfo = {
      id: 1,
      deviceName: "Nintendo 3DS",
      cpuModel: "ARM11 MPCore",
      cpuCores: 2,
      clockSpeed: 268,
      ramSize: 128,
      firmwareVersion: "11.17.0"
    };

    // Create default config with empty username
    this.createMiningConfig({
      userId: 1,
      poolUrl: "stratum+tcp://server.duinocoin.com:2813",
      workerName: "3DS_Miner",
      username: "",
      algorithm: "duino",
      intensity: 1,
      targetHashRate: 100,
      powerLimit: 85,
      isActive: false,
      rigIdentifier: "3DS"
    }).catch(() => {
      // Ignore errors during initialization
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getMiningConfig(userId: number): Promise<MiningConfig | undefined> {
    return Array.from(this.miningConfigs.values()).find(
      (config) => config.userId === userId
    );
  }

  async createMiningConfig(insertConfig: InsertMiningConfig): Promise<MiningConfig> {
    const id = this.currentConfigId++;
    const config: MiningConfig = { 
      ...insertConfig, 
      id,
      algorithm: insertConfig.algorithm || "duino",
      intensity: insertConfig.intensity || 1,
      powerLimit: insertConfig.powerLimit || 85,
      isActive: insertConfig.isActive || false,
      targetHashRate: insertConfig.targetHashRate || 100,
      rigIdentifier: insertConfig.rigIdentifier || "3DS"
    };
    this.miningConfigs.set(id, config);
    return config;
  }

  async updateMiningConfig(userId: number, updates: Partial<MiningConfig>): Promise<MiningConfig | undefined> {
    const existingConfig = await this.getMiningConfig(userId);
    if (!existingConfig) return undefined;
    
    const updatedConfig = { ...existingConfig, ...updates };
    this.miningConfigs.set(existingConfig.id, updatedConfig);
    return updatedConfig;
  }

  async getMiningStats(userId: number, limit = 50): Promise<MiningStats[]> {
    const userStats = this.miningStats.get(userId) || [];
    return userStats.slice(-limit).reverse();
  }

  async createMiningStats(insertStats: InsertMiningStats): Promise<MiningStats> {
    const id = this.currentStatsId++;
    const stats: MiningStats = { 
      ...insertStats, 
      id, 
      timestamp: new Date(),
      sharesAccepted: insertStats.sharesAccepted || 0,
      sharesRejected: insertStats.sharesRejected || 0,
      temperature: insertStats.temperature || 45,
      powerDraw: insertStats.powerDraw || 2.5,
      uptime: insertStats.uptime || 0
    };
    
    const userStats = this.miningStats.get(insertStats.userId) || [];
    userStats.push(stats);
    this.miningStats.set(insertStats.userId, userStats);
    
    return stats;
  }

  async getLatestMiningStats(userId: number): Promise<MiningStats | undefined> {
    const userStats = this.miningStats.get(userId) || [];
    return userStats[userStats.length - 1];
  }

  async getHardwareInfo(): Promise<HardwareInfo | undefined> {
    return this.hardwareInfo;
  }

  async createHardwareInfo(insertInfo: InsertHardwareInfo): Promise<HardwareInfo> {
    const info: HardwareInfo = { 
      ...insertInfo, 
      id: 1,
      deviceName: insertInfo.deviceName || "Nintendo 3DS",
      cpuModel: insertInfo.cpuModel || "ARM11 MPCore",
      cpuCores: insertInfo.cpuCores || 2,
      clockSpeed: insertInfo.clockSpeed || 268,
      ramSize: insertInfo.ramSize || 128,
      firmwareVersion: insertInfo.firmwareVersion || "11.17.0"
    };
    this.hardwareInfo = info;
    return info;
  }

  async updateHardwareInfo(updates: Partial<HardwareInfo>): Promise<HardwareInfo | undefined> {
    if (!this.hardwareInfo) return undefined;
    
    this.hardwareInfo = { ...this.hardwareInfo, ...updates };
    return this.hardwareInfo;
  }
}

export const storage = new MemStorage();
