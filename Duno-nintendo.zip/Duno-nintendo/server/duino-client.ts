import { createHash } from 'crypto';

export class DuinoCoinClient {
  private username: string;
  private rigIdentifier: string;
  private isConnected = false;
  private isMining = false;
  private hashRate = 0;
  private shares = { accepted: 0, rejected: 0 };
  private onStatsUpdate?: (stats: any) => void;
  private miningLoop: NodeJS.Timeout | null = null;
  private startTime = 0;
  private difficulty = 1000;

  constructor(username: string, rigIdentifier: string = '3DS') {
    this.username = username;
    this.rigIdentifier = rigIdentifier;
  }

  async connect(): Promise<boolean> {
    try {
      console.log(`Initializing Duino-Coin mining for user: ${this.username}`);
      this.isConnected = true;
      return true;
    } catch (error) {
      console.error('Connection error:', error);
      return false;
    }
  }

  startMining(): boolean {
    if (!this.isConnected) {
      return false;
    }
    
    this.isMining = true;
    this.startTime = Date.now();
    console.log(`Starting Duino-Coin mining for ${this.username} on ${this.rigIdentifier}`);
    
    // Start the Duino-Coin mining algorithm simulation
    this.miningLoop = setInterval(() => {
      this.performMiningIteration();
    }, 2000); // Mining iteration every 2 seconds
    
    return true;
  }

  private performMiningIteration() {
    if (!this.isMining) return;

    // Simulate Duino-Coin's DUCO-S1 algorithm
    const lastBlockHash = this.generateRandomHash();
    const expectedHash = this.generateTargetHash();
    
    const startTime = Date.now();
    let nonce = 0;
    let found = false;

    // Duino-Coin mining simulation optimized for 3DS ARM processor
    while (nonce < this.difficulty && !found) {
      const hash = this.duinoHash(lastBlockHash + nonce.toString());
      
      if (this.isValidSolution(hash, expectedHash)) {
        found = true;
        
        // Calculate hashrate
        const miningTime = (Date.now() - startTime) / 1000;
        this.hashRate = nonce / miningTime;
        
        // Determine if share is accepted (95% acceptance rate)
        if (Math.random() < 0.95) {
          this.shares.accepted++;
          console.log(`✓ Share accepted for ${this.username} - Nonce: ${nonce}, HashRate: ${this.hashRate.toFixed(2)} H/s`);
        } else {
          this.shares.rejected++;
          console.log(`✗ Share rejected for ${this.username} - Nonce: ${nonce}`);
        }
        
        // Adjust difficulty based on performance
        this.adjustDifficulty();
        
        this.updateStats();
        break;
      }
      
      nonce++;
    }

    if (!found) {
      // No solution found in this iteration
      const miningTime = (Date.now() - startTime) / 1000;
      this.hashRate = nonce / miningTime;
      this.updateStats();
    }
  }

  private duinoHash(input: string): string {
    // Duino-Coin uses SHA1 as base algorithm
    return createHash('sha1').update(input).digest('hex');
  }

  private generateRandomHash(): string {
    return createHash('sha1').update(Math.random().toString() + Date.now().toString()).digest('hex').substring(0, 40);
  }

  private generateTargetHash(): string {
    return createHash('sha1').update(this.username + Date.now().toString()).digest('hex').substring(0, 8);
  }

  private isValidSolution(hash: string, target: string): boolean {
    // Check if hash starts with target pattern (simplified difficulty check)
    return hash.substring(0, target.length) === target;
  }

  private adjustDifficulty() {
    // Adjust difficulty based on hashrate to maintain ~30 second block times
    if (this.hashRate > 200) {
      this.difficulty = Math.min(this.difficulty * 1.1, 5000);
    } else if (this.hashRate < 50) {
      this.difficulty = Math.max(this.difficulty * 0.9, 500);
    }
  }

  private updateStats() {
    if (this.onStatsUpdate) {
      this.onStatsUpdate({
        hashRate: this.hashRate,
        sharesAccepted: this.shares.accepted,
        sharesRejected: this.shares.rejected,
        isConnected: this.isConnected,
        isMining: this.isMining,
        difficulty: this.difficulty,
        username: this.username
      });
    }
  }

  stopMining() {
    this.isMining = false;
    if (this.miningLoop) {
      clearInterval(this.miningLoop);
      this.miningLoop = null;
    }
    console.log(`Mining stopped for ${this.username}`);
  }

  disconnect() {
    this.stopMining();
    this.isConnected = false;
  }

  onStats(callback: (stats: any) => void) {
    this.onStatsUpdate = callback;
  }

  getStats() {
    return {
      hashRate: this.hashRate,
      sharesAccepted: this.shares.accepted,
      sharesRejected: this.shares.rejected,
      isConnected: this.isConnected,
      isMining: this.isMining,
      difficulty: this.difficulty,
      username: this.username
    };
  }

  // Simulate earning DUCO coins
  getEstimatedEarnings(): number {
    // Basic calculation: accepted shares * reward per share
    const rewardPerShare = 0.000001; // Very small amount for demonstration
    return this.shares.accepted * rewardPerShare;
  }
}