import { pgTable, text, serial, integer, boolean, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const miningConfigs = pgTable("mining_configs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  poolUrl: text("pool_url").notNull(),
  workerName: text("worker_name").notNull(),
  username: text("username").notNull(),
  algorithm: text("algorithm").notNull().default("duino"),
  intensity: integer("intensity").notNull().default(1),
  targetHashRate: real("target_hash_rate").default(100),
  powerLimit: integer("power_limit").notNull().default(85),
  isActive: boolean("is_active").notNull().default(false),
  rigIdentifier: text("rig_identifier").default("3DS"),
});

export const miningStats = pgTable("mining_stats", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  hashRate: real("hash_rate").notNull(),
  sharesAccepted: integer("shares_accepted").notNull().default(0),
  sharesRejected: integer("shares_rejected").notNull().default(0),
  temperature: real("temperature").default(45.0),
  powerDraw: real("power_draw").default(2.5),
  uptime: integer("uptime").notNull().default(0),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const hardwareInfo = pgTable("hardware_info", {
  id: serial("id").primaryKey(),
  deviceName: text("device_name").notNull().default("Nintendo 3DS"),
  cpuModel: text("cpu_model").notNull().default("ARM11 MPCore"),
  cpuCores: integer("cpu_cores").notNull().default(2),
  clockSpeed: integer("clock_speed").notNull().default(268),
  ramSize: integer("ram_size").notNull().default(128),
  firmwareVersion: text("firmware_version").default("11.17.0"),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertMiningConfigSchema = createInsertSchema(miningConfigs).omit({
  id: true,
});

export const insertMiningStatsSchema = createInsertSchema(miningStats).omit({
  id: true,
  timestamp: true,
});

export const insertHardwareInfoSchema = createInsertSchema(hardwareInfo).omit({
  id: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type MiningConfig = typeof miningConfigs.$inferSelect;
export type InsertMiningConfig = z.infer<typeof insertMiningConfigSchema>;

export type MiningStats = typeof miningStats.$inferSelect;
export type InsertMiningStats = z.infer<typeof insertMiningStatsSchema>;

export type HardwareInfo = typeof hardwareInfo.$inferSelect;
export type InsertHardwareInfo = z.infer<typeof insertHardwareInfoSchema>;
