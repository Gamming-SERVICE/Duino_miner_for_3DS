import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { miningEngine } from "@/lib/mining-engine";

export function useMining() {
  const { toast } = useToast();

  const startMining = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/mining/start");
      return response.json();
    },
    onSuccess: () => {
      // Start the mining engine simulation
      miningEngine.start();
      
      // Start generating stats
      startStatsGeneration();
      
      queryClient.invalidateQueries({ queryKey: ["/api/mining/config"] });
      toast({
        title: "Mining Started",
        description: "3DS mining operation has begun successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to start mining operation.",
        variant: "destructive",
      });
    },
  });

  const stopMining = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/mining/stop");
      return response.json();
    },
    onSuccess: () => {
      // Stop the mining engine simulation
      miningEngine.stop();
      
      queryClient.invalidateQueries({ queryKey: ["/api/mining/config"] });
      toast({
        title: "Mining Stopped",
        description: "3DS mining operation has been halted.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to stop mining operation.",
        variant: "destructive",
      });
    },
  });

  // Generate mining statistics periodically
  const startStatsGeneration = () => {
    const generateStats = async () => {
      const stats = miningEngine.getCurrentStats();
      
      if (stats.isRunning) {
        try {
          await apiRequest("POST", "/api/mining/stats", {
            hashRate: stats.hashRate,
            sharesAccepted: stats.sharesAccepted,
            sharesRejected: stats.sharesRejected,
            temperature: stats.temperature,
            powerDraw: stats.powerDraw,
            uptime: stats.uptime,
          });
          
          // Invalidate queries to refresh UI
          queryClient.invalidateQueries({ queryKey: ["/api/mining/stats"] });
          queryClient.invalidateQueries({ queryKey: ["/api/mining/stats/latest"] });
          
          // Continue generating stats if still mining
          setTimeout(generateStats, 5000);
        } catch (error) {
          console.error("Failed to generate mining stats:", error);
        }
      }
    };

    // Start generating stats after a short delay
    setTimeout(generateStats, 1000);
  };

  return {
    startMining: startMining.mutate,
    stopMining: stopMining.mutate,
    isStarting: startMining.isPending,
    isStopping: stopMining.isPending,
  };
}
