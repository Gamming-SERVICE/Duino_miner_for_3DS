import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { 
  Home, 
  Settings, 
  Server, 
  Monitor,
  Activity
} from "lucide-react";
import type { MiningConfig } from "@shared/schema";

export default function Navigation() {
  const [location] = useLocation();
  
  const { data: config } = useQuery<MiningConfig>({
    queryKey: ["/api/mining/config"],
  });

  const navItems = [
    { path: "/", icon: Home, label: "Dashboard" },
    { path: "/config", icon: Settings, label: "Config" },
    { path: "/pool", icon: Server, label: "Pool" },
    { path: "/hardware", icon: Monitor, label: "Hardware" },
  ];

  return (
    <nav className="flex items-center justify-between p-4 border-b">
      <div className="flex items-center gap-2">
        <Activity className="w-6 h-6 text-primary" />
        <h1 className="text-lg font-bold">3DS Miner</h1>
        {config?.isActive && (
          <Badge variant="default" className="animate-pulse">Live</Badge>
        )}
      </div>
      
      <div className="flex gap-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.path;
          
          return (
            <Link key={item.path} href={item.path}>
              <Button
                variant={isActive ? "default" : "ghost"}
                size="sm"
                className="flex items-center gap-1"
              >
                <Icon className="w-4 h-4" />
                <span className="hidden sm:inline">{item.label}</span>
              </Button>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
