import { ReactNode } from "react";
import { Card } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

interface DualScreenLayoutProps {
  children: ReactNode;
}

export default function DualScreenLayout({ children }: DualScreenLayoutProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-blue-100 dark:from-gray-900 dark:to-gray-800">
      {/* Top Screen Simulation */}
      <Card className="mx-4 pt-4 pb-2 rounded-t-lg rounded-b-none border-b-0 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="px-4">
          <div className="text-white text-center">
            <h2 className="text-sm font-semibold">Nintendo 3DS - Top Screen</h2>
            <p className="text-xs opacity-80">Duino Mining System v1.0</p>
          </div>
        </div>
      </Card>

      {/* Screen Separator */}
      <div className="mx-4 bg-gray-800 h-8 flex items-center justify-center">
        <div className="flex space-x-1">
          <div className="w-2 h-2 bg-gray-600 rounded-full"></div>
          <div className="w-2 h-2 bg-gray-600 rounded-full"></div>
          <div className="w-2 h-2 bg-gray-600 rounded-full"></div>
        </div>
      </div>

      {/* Bottom Screen Simulation - Main Content */}
      <Card className="mx-4 min-h-[calc(100vh-8rem)] rounded-t-none rounded-b-lg border-t-0 flex flex-col">
        <div className="bg-gradient-to-r from-gray-100 to-gray-200 dark:from-gray-800 dark:to-gray-700 px-4 py-2 text-center">
          <p className="text-xs text-muted-foreground">Nintendo 3DS - Bottom Screen (Touch)</p>
        </div>
        <Separator />
        <div className="flex-1 flex flex-col">
          {children}
        </div>
      </Card>

      {/* Device Frame Effect */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent transform rotate-45 translate-x-full animate-pulse"></div>
      </div>
    </div>
  );
}
