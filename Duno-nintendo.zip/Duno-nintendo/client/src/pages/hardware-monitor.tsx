import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Cpu, 
  Thermometer, 
  Zap, 
  HardDrive, 
  Wifi,
  Battery,
  Monitor,
  Smartphone
} from "lucide-react";
import type { HardwareInfo, MiningStats } from "@shared/schema";

export default function HardwareMonitor() {
  const { data: hardware } = useQuery<HardwareInfo>({
    queryKey: ["/api/hardware"],
  });

  const { data: latestStats } = useQuery<MiningStats>({
    queryKey: ["/api/mining/stats/latest"],
    refetchInterval: 2000,
  });

  // Mock additional hardware data
  const systemInfo = {
    cpuUsage: 75,
    ramUsage: 65,
    batteryLevel: 78,
    wifiSignal: -45,
    screenBrightness: 80,
    systemLoad: [0.8, 1.2, 0.9],
  };

  const getTemperatureColor = (temp: number) => {
    if (temp > 70) return "text-red-500";
    if (temp > 60) return "text-yellow-500";
    return "text-green-500";
  };

  const getTemperatureStatus = (temp: number) => {
    if (temp > 70) return "Critical";
    if (temp > 60) return "Warning";
    return "Normal";
  };

  const getWifiStrength = (signal: number) => {
    if (signal > -30) return "Excellent";
    if (signal > -50) return "Good";
    if (signal > -70) return "Fair";
    return "Poor";
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Smartphone className="w-6 h-6" />
        <h1 className="text-3xl font-bold">Hardware Monitor</h1>
      </div>

      {/* Device Information */}
      <Card>
        <CardHeader>
          <CardTitle>Device Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Device</p>
              <p className="font-bold">{hardware?.deviceName || "Nintendo 3DS"}</p>
            </div>
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">CPU Model</p>
              <p className="font-bold">{hardware?.cpuModel || "ARM11 MPCore"}</p>
            </div>
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Firmware</p>
              <p className="font-bold">{hardware?.firmwareVersion || "11.17.0"}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* System Status */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">CPU Usage</CardTitle>
            <Cpu className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{systemInfo.cpuUsage}%</div>
            <Progress value={systemInfo.cpuUsage} className="mt-2" />
            <p className="text-xs text-muted-foreground mt-1">
              {hardware?.cpuCores || 2} cores @ {hardware?.clockSpeed || 268}MHz
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Temperature</CardTitle>
            <Thermometer className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${getTemperatureColor(latestStats?.temperature || 45)}`}>
              {latestStats?.temperature?.toFixed(1) || "45.0"}°C
            </div>
            <Badge 
              variant={latestStats?.temperature && latestStats.temperature > 60 ? "destructive" : "default"}
              className="mt-2"
            >
              {getTemperatureStatus(latestStats?.temperature || 45)}
            </Badge>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">RAM Usage</CardTitle>
            <HardDrive className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{systemInfo.ramUsage}%</div>
            <Progress value={systemInfo.ramUsage} className="mt-2" />
            <p className="text-xs text-muted-foreground mt-1">
              {hardware?.ramSize || 128}MB Total
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Power Draw</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {latestStats?.powerDraw?.toFixed(1) || "2.5"}W
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Current consumption
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Additional System Info */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>System Resources</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm">CPU Cores</span>
                <span className="font-bold">{hardware?.cpuCores || 2}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Clock Speed</span>
                <span className="font-bold">{hardware?.clockSpeed || 268} MHz</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Total RAM</span>
                <span className="font-bold">{hardware?.ramSize || 128} MB</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Available RAM</span>
                <span className="font-bold">
                  {Math.round(((hardware?.ramSize || 128) * (100 - systemInfo.ramUsage)) / 100)} MB
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Connectivity & Power</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Battery className="w-4 h-4" />
                <span className="text-sm">Battery Level</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-bold">{systemInfo.batteryLevel}%</span>
                <Progress value={systemInfo.batteryLevel} className="w-16 h-2" />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Wifi className="w-4 h-4" />
                <span className="text-sm">WiFi Signal</span>
              </div>
              <div className="text-right">
                <span className="font-bold">{systemInfo.wifiSignal} dBm</span>
                <p className="text-xs text-muted-foreground">
                  {getWifiStrength(systemInfo.wifiSignal)}
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Monitor className="w-4 h-4" />
                <span className="text-sm">Screen Brightness</span>
              </div>
              <span className="font-bold">{systemInfo.screenBrightness}%</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* System Load History */}
      <Card>
        <CardHeader>
          <CardTitle>System Load Average</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <p className="text-2xl font-bold">{systemInfo.systemLoad[0].toFixed(2)}</p>
              <p className="text-sm text-muted-foreground">1 minute</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold">{systemInfo.systemLoad[1].toFixed(2)}</p>
              <p className="text-sm text-muted-foreground">5 minutes</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold">{systemInfo.systemLoad[2].toFixed(2)}</p>
              <p className="text-sm text-muted-foreground">15 minutes</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
