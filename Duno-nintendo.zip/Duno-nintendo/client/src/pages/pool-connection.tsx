import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { 
  Wifi, 
  WifiOff, 
  Server, 
  Users, 
  TrendingUp, 
  Clock,
  CheckCircle,
  XCircle,
  AlertTriangle
} from "lucide-react";
import type { MiningConfig, MiningStats } from "@shared/schema";

export default function PoolConnection() {
  const { data: config } = useQuery<MiningConfig>({
    queryKey: ["/api/mining/config"],
  });

  const { data: latestStats } = useQuery<MiningStats>({
    queryKey: ["/api/mining/stats/latest"],
    refetchInterval: 5000,
  });

  // Mock pool data (in real implementation, this would come from the pool API)
  const poolData = {
    connected: config?.isActive || false,
    latency: 45,
    difficulty: 12500,
    workers: 1247,
    poolHashRate: "15.7 MH/s",
    userHashRate: latestStats?.hashRate || 0,
    nextPayout: "0.00124 DUCO",
    estimatedTime: "2h 15m",
  };

  const connectionStatus = poolData.connected ? "Connected" : "Disconnected";
  const connectionColor = poolData.connected ? "default" : "destructive";
  const ConnectionIcon = poolData.connected ? Wifi : WifiOff;

  const shareAcceptanceRate = latestStats?.sharesAccepted && latestStats?.sharesRejected 
    ? (latestStats.sharesAccepted / (latestStats.sharesAccepted + latestStats.sharesRejected)) * 100
    : 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Server className="w-6 h-6" />
        <h1 className="text-3xl font-bold">Pool Connection</h1>
      </div>

      {/* Connection Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ConnectionIcon className="w-5 h-5" />
            Connection Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="space-y-2">
              <Badge variant={connectionColor} className="text-sm">
                {connectionStatus}
              </Badge>
              <p className="text-sm text-muted-foreground">
                {config?.poolUrl || "No pool configured"}
              </p>
            </div>
            {poolData.connected && (
              <div className="text-right space-y-1">
                <p className="text-sm font-medium">Latency: {poolData.latency}ms</p>
                <p className="text-sm text-muted-foreground">Worker: {config?.workerName}</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Pool Statistics */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pool Hash Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{poolData.poolHashRate}</div>
            <p className="text-xs text-muted-foreground">
              Total network power
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Workers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{poolData.workers.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              Connected miners
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Difficulty</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{poolData.difficulty.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              Current network difficulty
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Mining Performance */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Share Statistics</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span className="text-sm">Accepted Shares</span>
              </div>
              <span className="font-bold">{latestStats?.sharesAccepted || 0}</span>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <XCircle className="w-4 h-4 text-red-500" />
                <span className="text-sm">Rejected Shares</span>
              </div>
              <span className="font-bold">{latestStats?.sharesRejected || 0}</span>
            </div>

            <Separator />
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Acceptance Rate</span>
                <span>{shareAcceptanceRate.toFixed(1)}%</span>
              </div>
              <Progress value={shareAcceptanceRate} className="h-2" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Payout Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Next Payout</span>
              <span className="font-bold">{poolData.nextPayout}</span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Estimated Time</span>
              <span className="font-bold">{poolData.estimatedTime}</span>
            </div>

            <Separator />
            
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Your Hash Rate</span>
              <span className="font-bold">{poolData.userHashRate.toFixed(2)} H/s</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Connection Actions */}
      {!poolData.connected && (
        <Card>
          <CardHeader>
            <CardTitle>Connection Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2">
              <Button>Test Connection</Button>
              <Button variant="outline">Retry Connection</Button>
            </div>
            <p className="text-sm text-muted-foreground mt-2">
              Make sure your pool configuration is correct and the pool server is reachable.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
