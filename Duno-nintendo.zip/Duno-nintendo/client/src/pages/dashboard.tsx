import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import MiningStats from "@/components/mining-stats";
import { useMining } from "@/hooks/use-mining";
import { Play, Square, Cpu, Thermometer, Zap, Clock } from "lucide-react";
import type { MiningConfig, MiningStats as MiningStatsType } from "@shared/schema";

export default function Dashboard() {
  const { data: config } = useQuery<MiningConfig>({
    queryKey: ["/api/mining/config"],
  });

  const { data: latestStats } = useQuery<MiningStatsType>({
    queryKey: ["/api/mining/stats/latest"],
    refetchInterval: 2000,
  });

  const { startMining, stopMining, isStarting, isStopping } = useMining();

  const handleToggleMining = () => {
    if (config?.isActive) {
      stopMining();
    } else {
      startMining();
    }
  };

  const formatUptime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}h ${minutes}m`;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Duino Mining Dashboard</h1>
          <p className="text-muted-foreground">Nintendo 3DS Homebrew Mining</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant={config?.isActive ? "default" : "secondary"}>
            {config?.isActive ? "Mining Active" : "Mining Stopped"}
          </Badge>
          <Button
            onClick={handleToggleMining}
            disabled={isStarting || isStopping}
            variant={config?.isActive ? "destructive" : "default"}
          >
            {config?.isActive ? (
              <>
                <Square className="w-4 h-4 mr-2" />
                Stop Mining
              </>
            ) : (
              <>
                <Play className="w-4 h-4 mr-2" />
                Start Mining
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Quick Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Hash Rate</CardTitle>
            <Cpu className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {latestStats?.hashRate?.toFixed(2) || "0.00"} H/s
            </div>
            <p className="text-xs text-muted-foreground">
              Current mining speed
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Temperature</CardTitle>
            <Thermometer className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {latestStats?.temperature?.toFixed(1) || "0.0"}°C
            </div>
            <Progress 
              value={(latestStats?.temperature || 0) / 85 * 100} 
              className="mt-2"
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Power Draw</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {latestStats?.powerDraw?.toFixed(1) || "0.0"}W
            </div>
            <p className="text-xs text-muted-foreground">
              Current consumption
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Uptime</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatUptime(latestStats?.uptime || 0)}
            </div>
            <p className="text-xs text-muted-foreground">
              Mining session time
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Shares Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Shares Accepted</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">
              {latestStats?.sharesAccepted || 0}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Shares Rejected</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-red-600">
              {latestStats?.sharesRejected || 0}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Mining Statistics Chart */}
      <MiningStats />
    </div>
  );
}
