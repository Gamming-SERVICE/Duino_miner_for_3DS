import { useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertMiningConfigSchema, type MiningConfig } from "@shared/schema";
import { Settings, Save } from "lucide-react";
import { z } from "zod";

const configSchema = insertMiningConfigSchema.extend({
  poolUrl: z.string().url("Please enter a valid pool URL"),
  workerName: z.string().min(1, "Worker name is required"),
  username: z.string().min(1, "Duino-Coin username is required"),
  intensity: z.number().min(1).max(10),
  powerLimit: z.number().min(50).max(100),
});

type ConfigFormData = z.infer<typeof configSchema>;

export default function MiningConfig() {
  const { toast } = useToast();

  const { data: config, isLoading } = useQuery<MiningConfig>({
    queryKey: ["/api/mining/config"],
  });

  const form = useForm<ConfigFormData>({
    resolver: zodResolver(configSchema),
    defaultValues: {
      poolUrl: config?.poolUrl || "stratum+tcp://server.duinocoin.com:2813",
      workerName: config?.workerName || "3DS_Miner",
      username: config?.username || "",
      algorithm: config?.algorithm || "duino",
      intensity: config?.intensity || 1,
      targetHashRate: config?.targetHashRate || 100,
      powerLimit: config?.powerLimit || 85,
      isActive: config?.isActive || false,
    },
  });

  // Update form when config loads
  useEffect(() => {
    if (config) {
      form.reset({
        poolUrl: config.poolUrl,
        workerName: config.workerName,
        username: config.username,
        algorithm: config.algorithm,
        intensity: config.intensity,
        targetHashRate: config.targetHashRate || 100,
        powerLimit: config.powerLimit,
        isActive: config.isActive,
      });
    }
  }, [config, form]);

  const saveConfig = useMutation({
    mutationFn: async (data: ConfigFormData) => {
      console.log('Submitting config data:', data);
      // Add userId to the data like the test button does
      const configData = { ...data, userId: 1 };
      console.log('Config data with userId:', configData);
      const response = await apiRequest("POST", "/api/mining/config", configData);
      return response.json();
    },
    onSuccess: (data) => {
      console.log('Config saved successfully:', data);
      queryClient.invalidateQueries({ queryKey: ["/api/mining/config"] });
      toast({
        title: "Configuration Saved",
        description: "Mining configuration has been updated successfully.",
      });
    },
    onError: (error) => {
      console.error('Config save error:', error);
      toast({
        title: "Error",
        description: "Failed to save mining configuration.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ConfigFormData) => {
    console.log('Form submitted with data:', data);
    console.log('Form errors:', form.formState.errors);
    
    // Direct save with explicit data structure
    const configData = {
      userId: 1,
      poolUrl: data.poolUrl || "stratum+tcp://server.duinocoin.com:2813",
      workerName: data.workerName || "3DS_Miner",
      username: data.username || "",
      algorithm: "duino" as const,
      intensity: data.intensity || 1,
      targetHashRate: data.targetHashRate || 100,
      powerLimit: data.powerLimit || 85,
      isActive: data.isActive || false,
      rigIdentifier: data.rigIdentifier || "3DS"
    };
    
    console.log('Direct save with config:', configData);
    saveConfig.mutate(configData);
  };

  // Manual save function for direct button click
  const handleDirectSave = () => {
    const formValues = form.getValues();
    console.log('Current form values:', formValues);
    
    const configData = {
      userId: 1,
      poolUrl: formValues.poolUrl || "stratum+tcp://server.duinocoin.com:2813",
      workerName: formValues.workerName || "3DS_Miner", 
      username: formValues.username || "",
      algorithm: "duino" as const,
      intensity: formValues.intensity || 1,
      targetHashRate: formValues.targetHashRate || 100,
      powerLimit: formValues.powerLimit || 85,
      isActive: formValues.isActive || false,
      rigIdentifier: formValues.rigIdentifier || "3DS"
    };
    
    console.log('Manual save with config:', configData);
    saveConfig.mutate(configData);
  };



  if (isLoading) {
    return <div>Loading configuration...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Settings className="w-6 h-6" />
        <h1 className="text-3xl font-bold">Mining Configuration</h1>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Pool Configuration */}
            <Card>
              <CardHeader>
                <CardTitle>Pool Configuration</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <FormField
                  control={form.control}
                  name="poolUrl"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Pool URL</FormLabel>
                      <FormControl>
                        <Input placeholder="stratum+tcp://server.duinocoin.com:2813" {...field} />
                      </FormControl>
                      <FormDescription>
                        Mining pool server address and port
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="workerName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Worker Name</FormLabel>
                      <FormControl>
                        <Input placeholder="3DS_Miner" {...field} />
                      </FormControl>
                      <FormDescription>
                        Unique identifier for this mining device
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Duino-Coin Username</FormLabel>
                      <FormControl>
                        <Input placeholder="your_duino_username" {...field} />
                      </FormControl>
                      <FormDescription>
                        Your Duino-Coin account username for mining rewards
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="algorithm"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Mining Algorithm</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select algorithm" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="duino">Duino-Coin</SelectItem>
                          <SelectItem value="xxhash">XXHash</SelectItem>
                          <SelectItem value="sha1">SHA1</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        Optimized for 3DS ARM processor
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>

            {/* Performance Settings */}
            <Card>
              <CardHeader>
                <CardTitle>Performance Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <FormField
                  control={form.control}
                  name="intensity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Mining Intensity: {field.value}</FormLabel>
                      <FormControl>
                        <Slider
                          min={1}
                          max={10}
                          step={1}
                          value={[field.value]}
                          onValueChange={(value) => field.onChange(value[0])}
                        />
                      </FormControl>
                      <FormDescription>
                        Higher intensity = more hash rate but more power usage
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="targetHashRate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Target Hash Rate (H/s)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          {...field} 
                          value={field.value || ""}
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                        />
                      </FormControl>
                      <FormDescription>
                        Expected performance target for this device
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="powerLimit"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Power Limit: {field.value}%</FormLabel>
                      <FormControl>
                        <Slider
                          min={50}
                          max={100}
                          step={5}
                          value={[field.value]}
                          onValueChange={(value) => field.onChange(value[0])}
                        />
                      </FormControl>
                      <FormDescription>
                        Limit power consumption to preserve battery life
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>
          </div>

          <div className="flex justify-end">
            <Button type="button" onClick={handleDirectSave} disabled={saveConfig.isPending}>
              <Save className="w-4 h-4 mr-2" />
              {saveConfig.isPending ? "Saving..." : "Save Configuration"}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}
