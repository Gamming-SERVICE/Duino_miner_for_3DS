import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import MiningConfig from "@/pages/mining-config";
import PoolConnection from "@/pages/pool-connection";
import HardwareMonitor from "@/pages/hardware-monitor";
import Navigation from "@/components/navigation";
import DualScreenLayout from "@/components/dual-screen-layout";

function Router() {
  return (
    <DualScreenLayout>
      <Navigation />
      <div className="flex-1 p-4">
        <Switch>
          <Route path="/" component={Dashboard} />
          <Route path="/config" component={MiningConfig} />
          <Route path="/pool" component={PoolConnection} />
          <Route path="/hardware" component={HardwareMonitor} />
          <Route component={NotFound} />
        </Switch>
      </div>
    </DualScreenLayout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
